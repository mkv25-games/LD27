Ludum Dare 27
August 2013

Theme: 10 seconds
Go!

A medieval quest to gain land and gold.
